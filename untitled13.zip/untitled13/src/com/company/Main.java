package com.company;

public class Main {

    public static void main(String[] args) {

        Runner runner1 = new Runner("Runner 1");
        runner1.start();

    }
}
